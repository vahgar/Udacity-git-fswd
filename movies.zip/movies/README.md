Modules : freshtomatoes.py and media.py

Simple steps to run this script:

1. Go to directory which has entertainment_center.py file
2. Type : python entertainment_center.py
